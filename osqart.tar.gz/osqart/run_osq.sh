#!/bin/bash

/opt/osquery/bin/osqueryd --config_path=/etc/osquery/osquery.conf --verbose >& /var/log/osquery/osquery.out &

